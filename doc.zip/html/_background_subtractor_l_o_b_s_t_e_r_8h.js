var _background_subtractor_l_o_b_s_t_e_r_8h =
[
    [ "BackgroundSubtractorLOBSTER", "class_background_subtractor_l_o_b_s_t_e_r.html", "class_background_subtractor_l_o_b_s_t_e_r" ],
    [ "BGSLOBSTER_DEFAULT_COLOR_DIST_THRESHOLD", "_background_subtractor_l_o_b_s_t_e_r_8h.html#a8442ce9b67919b77ad15847e5d80d983", null ],
    [ "BGSLOBSTER_DEFAULT_DESC_DIST_THRESHOLD", "_background_subtractor_l_o_b_s_t_e_r_8h.html#a11b89942e22902c0bbbbc2f0154804c2", null ],
    [ "BGSLOBSTER_DEFAULT_LBSP_OFFSET_SIMILARITY_THRESHOLD", "_background_subtractor_l_o_b_s_t_e_r_8h.html#a705c59e9c9a6fd8c0c57a5adab5a72c0", null ],
    [ "BGSLOBSTER_DEFAULT_LBSP_REL_SIMILARITY_THRESHOLD", "_background_subtractor_l_o_b_s_t_e_r_8h.html#a3025dcc96b2d2c6416bfa57325d79ba5", null ],
    [ "BGSLOBSTER_DEFAULT_LEARNING_RATE", "_background_subtractor_l_o_b_s_t_e_r_8h.html#a2d317f4a065c4c58c7241080d9c4457c", null ],
    [ "BGSLOBSTER_DEFAULT_NB_BG_SAMPLES", "_background_subtractor_l_o_b_s_t_e_r_8h.html#aea7261dd4c4233733b24fd175b6cb2b3", null ],
    [ "BGSLOBSTER_DEFAULT_REQUIRED_NB_BG_SAMPLES", "_background_subtractor_l_o_b_s_t_e_r_8h.html#a209f60b8a126e31bb8ec6f8209d95ad0", null ]
];