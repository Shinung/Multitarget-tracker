var _background_subtractor_su_b_s_e_n_s_e_8h =
[
    [ "BackgroundSubtractorSuBSENSE", "class_background_subtractor_su_b_s_e_n_s_e.html", "class_background_subtractor_su_b_s_e_n_s_e" ],
    [ "BGSSUBSENSE_DEFAULT_DESC_DIST_THRESHOLD_OFFSET", "_background_subtractor_su_b_s_e_n_s_e_8h.html#a6ac17a78aeb1fb0dab4833b50b80e43e", null ],
    [ "BGSSUBSENSE_DEFAULT_LBSP_REL_SIMILARITY_THRESHOLD", "_background_subtractor_su_b_s_e_n_s_e_8h.html#a125c1e09337744e8b4a35da8696dc5d4", null ],
    [ "BGSSUBSENSE_DEFAULT_MIN_COLOR_DIST_THRESHOLD", "_background_subtractor_su_b_s_e_n_s_e_8h.html#ab2d581a6cf91dca26bb660c483cdb23c", null ],
    [ "BGSSUBSENSE_DEFAULT_N_SAMPLES_FOR_MV_AVGS", "_background_subtractor_su_b_s_e_n_s_e_8h.html#acf2f1c0462353ddc7a51a6ed995a36ab", null ],
    [ "BGSSUBSENSE_DEFAULT_NB_BG_SAMPLES", "_background_subtractor_su_b_s_e_n_s_e_8h.html#a0140353a9cb83ccce1209024d570ff28", null ],
    [ "BGSSUBSENSE_DEFAULT_REQUIRED_NB_BG_SAMPLES", "_background_subtractor_su_b_s_e_n_s_e_8h.html#a3f30662673e2871e8f751e4ca1b433d1", null ]
];