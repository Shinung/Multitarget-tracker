var _base_detector_8cpp =
[
    [ "CreateDetector", "_base_detector_8cpp.html#a7648f35ed8e9d0160414d8e0eaf99c15", null ]
];