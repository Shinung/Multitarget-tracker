var _hungarian_alg_8h =
[
    [ "AssignmentProblemSolver", "class_assignment_problem_solver.html", "class_assignment_problem_solver" ],
    [ "assignments_t", "_hungarian_alg_8h.html#ad7b9f569a9adbd958c668a36b6884ffd", null ],
    [ "distMatrix_t", "_hungarian_alg_8h.html#af6ab0ee8259a51215f62e8f96416d5bb", null ]
];