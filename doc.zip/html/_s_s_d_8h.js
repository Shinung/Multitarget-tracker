var _s_s_d_8h =
[
    [ "BBox", "class_b_box.html", "class_b_box" ],
    [ "SSD", "class_s_s_d.html", "class_s_s_d" ],
    [ "USE_CUDNN", "_s_s_d_8h.html#a448d4af5372547bb6f1327e1fc81b6f4", null ],
    [ "DetectedBBoxes", "_s_s_d_8h.html#a6145f2543054bcfbafc56318060f727b", null ]
];