var _s_s_d_custom_net_detector_8cpp =
[
    [ "ExecContext", "class_exec_context.html", "class_exec_context" ],
    [ "CustomSSD_ctx", "struct_custom_s_s_d__ctx.html", "struct_custom_s_s_d__ctx" ],
    [ "kContextsPerDevice", "_s_s_d_custom_net_detector_8cpp.html#a123a352b9596fc7d507e96fbe9c44f41", null ]
];