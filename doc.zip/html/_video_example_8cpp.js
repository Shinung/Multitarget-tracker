var _video_example_8cpp =
[
    [ "GlobalInitGLOG", "_video_example_8cpp.html#abff23921233cecd3fb2eabc6109c8b70", null ]
];