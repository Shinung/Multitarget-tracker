var _video_example_8h =
[
    [ "VideoExample", "class_video_example.html", "class_video_example" ],
    [ "FrameInfo", "struct_video_example_1_1_frame_info.html", "struct_video_example_1_1_frame_info" ],
    [ "MotionDetectorExample", "class_motion_detector_example.html", "class_motion_detector_example" ],
    [ "FaceDetectorExample", "class_face_detector_example.html", "class_face_detector_example" ],
    [ "PedestrianDetectorExample", "class_pedestrian_detector_example.html", "class_pedestrian_detector_example" ],
    [ "SSDMobileNetExample", "class_s_s_d_mobile_net_example.html", "class_s_s_d_mobile_net_example" ],
    [ "YoloExample", "class_yolo_example.html", "class_yolo_example" ],
    [ "CustomSSDMobileNetExample", "class_custom_s_s_d_mobile_net_example.html", "class_custom_s_s_d_mobile_net_example" ],
    [ "GlobalInitGLOG", "_video_example_8h.html#abff23921233cecd3fb2eabc6109c8b70", null ]
];