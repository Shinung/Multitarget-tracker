var c4_pedestrian_detector_8cpp =
[
    [ "ComputeCT", "c4-pedestrian-detector_8cpp.html#a205804b2ee8558313222a898513a9543", null ],
    [ "LoadCascade", "c4-pedestrian-detector_8cpp.html#a1c2c730891bb9a5800d3761e8cfaa160", null ],
    [ "UseSVM_CD_FastEvaluationStructure", "c4-pedestrian-detector_8cpp.html#a1a25c5eeb6b4917c272b201ff023ba68", null ],
    [ "UseSVM_CD_FastEvaluationStructure", "c4-pedestrian-detector_8cpp.html#a891356b11fe09e40a8b2993bc8d00c01", null ]
];