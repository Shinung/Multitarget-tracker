var c4_pedestrian_detector_8h =
[
    [ "Array2dC", "class_array2d_c.html", "class_array2d_c" ],
    [ "Array2d", "class_array2d.html", "class_array2d" ],
    [ "Array2dC", "class_array2d_c.html", "class_array2d_c" ],
    [ "IntImage", "class_int_image.html", "class_int_image" ],
    [ "NodeDetector", "class_node_detector.html", "class_node_detector" ],
    [ "CascadeDetector", "class_cascade_detector.html", "class_cascade_detector" ],
    [ "DetectionScanner", "class_detection_scanner.html", "class_detection_scanner" ],
    [ "USE_DOUBLE", "c4-pedestrian-detector_8h.html#a3602f95fb57ccdebbb4e06786d23d033", null ],
    [ "REAL", "c4-pedestrian-detector_8h.html#a5821460e95a0800cf9f24c38915cbbde", null ],
    [ "LoadCascade", "c4-pedestrian-detector_8h.html#a1c2c730891bb9a5800d3761e8cfaa160", null ]
];