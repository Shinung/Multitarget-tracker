var class_assignment_problem_solver =
[
    [ "TMethod", "class_assignment_problem_solver.html#aec407eb73fed9d3ddb9467fde90a85e8", [
      [ "optimal", "class_assignment_problem_solver.html#aec407eb73fed9d3ddb9467fde90a85e8a84f2334f61866dba64befa6910848d75", null ],
      [ "many_forbidden_assignments", "class_assignment_problem_solver.html#aec407eb73fed9d3ddb9467fde90a85e8a226c2e4b79d0beeb342087880d97bb2a", null ],
      [ "without_forbidden_assignments", "class_assignment_problem_solver.html#aec407eb73fed9d3ddb9467fde90a85e8a3329e7571829a83b21be4821df62310d", null ]
    ] ],
    [ "AssignmentProblemSolver", "class_assignment_problem_solver.html#a13a83a34d4a0b4da872d87c79cb9c687", null ],
    [ "~AssignmentProblemSolver", "class_assignment_problem_solver.html#a47317b69e3eb9b50426c427ebcf5770f", null ],
    [ "assignmentoptimal", "class_assignment_problem_solver.html#a5b84a5167984db1050821926f52b5187", null ],
    [ "assignmentsuboptimal1", "class_assignment_problem_solver.html#ae8fddfafc7387f3597493f02e8366883", null ],
    [ "assignmentsuboptimal2", "class_assignment_problem_solver.html#a31277dc88cb22e07db1e52b6fe88f84f", null ],
    [ "buildassignmentvector", "class_assignment_problem_solver.html#a1aa1c05dec6aef723f5d41affc667a77", null ],
    [ "computeassignmentcost", "class_assignment_problem_solver.html#a978fa51f563d47dbd00c697704cf4ad9", null ],
    [ "Solve", "class_assignment_problem_solver.html#a38198467ca647403c40be2c2bb47e177", null ],
    [ "step2a", "class_assignment_problem_solver.html#adef6ec1494dd6058fdf1373bc2c6d6eb", null ],
    [ "step2b", "class_assignment_problem_solver.html#a069b78d89842031f7b54e0837c2bd602", null ],
    [ "step3_5", "class_assignment_problem_solver.html#a8c24dfcfef6adfb96c6394f798c02dba", null ],
    [ "step4", "class_assignment_problem_solver.html#a6ea85d386a136effd84c00f4e2f3cd77", null ]
];