var class_background_subtract =
[
    [ "BGFG_ALGS", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949f", [
      [ "ALG_VIBE", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949fa1905f812773a0029b59688e57990f172", null ],
      [ "ALG_MOG", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949fa6ce3f5db7dc79642df7c113be3a28d14", null ],
      [ "ALG_GMG", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949fa3d46f57cfb0a9b1b5b037b387a35f652", null ],
      [ "ALG_CNT", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949fa4e734ae21b8add9022427f8da9469cfb", null ],
      [ "ALG_SuBSENSE", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949fa0a4e184ec94bca58e58dd4226f1b1f7f", null ],
      [ "ALG_LOBSTER", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949fae4cc76d1ae01949bc7e6be6ed046ddaf", null ],
      [ "ALG_MOG2", "class_background_subtract.html#a56850081696df68b55f87b4f3d87949fa35994e745da8eb824d3808ee50ad3ebf", null ]
    ] ],
    [ "BackgroundSubtract", "class_background_subtract.html#a0b5096a3823c7af66b6d22cdd36e8fda", null ],
    [ "~BackgroundSubtract", "class_background_subtract.html#ac811f4c717052b81d1e0bd633d265423", null ],
    [ "Init", "class_background_subtract.html#a9dacb4cc5cf41c4a37cc776a8142aecc", null ],
    [ "Subtract", "class_background_subtract.html#a1cd989730164da1c2523975d2ed32147", null ],
    [ "m_algType", "class_background_subtract.html#a3d569052b6954fa87f04a0aa8a970f97", null ],
    [ "m_channels", "class_background_subtract.html#a676897a571788e0fee84d568bc68caf0", null ],
    [ "m_modelOCV", "class_background_subtract.html#a80782a38138a430437095f625603e599", null ],
    [ "m_modelSuBSENSE", "class_background_subtract.html#a56275963c8cacca97b97d0cde884f4c1", null ],
    [ "m_modelVibe", "class_background_subtract.html#a57c251abeed9a2c73a3c97d0f7f8b527", null ]
];