var class_base_detector =
[
    [ "BaseDetector", "class_base_detector.html#a3c85e13a47dd472319dc43c60f0d102a", null ],
    [ "~BaseDetector", "class_base_detector.html#afc5cc0ccdbc1fc1b60371f22bed620fd", null ],
    [ "CalcMotionMap", "class_base_detector.html#a73c66f0d4dad263fcf65c09a6f6feda2", null ],
    [ "CollectPoints", "class_base_detector.html#a20380b0980c6f262b0829f37fb89d2a7", null ],
    [ "Detect", "class_base_detector.html#a9c9dedfffb7673fd2995f24bdb9ade18", null ],
    [ "GetDetects", "class_base_detector.html#a52ac4b2feed15a47de84a69eb45c233f", null ],
    [ "Init", "class_base_detector.html#a44c53608e9e4e3455ff553d987165260", null ],
    [ "SetMinObjectSize", "class_base_detector.html#ab459f4e77cf1110cc1ee84027f0f2a03", null ],
    [ "m_collectPoints", "class_base_detector.html#a403cbf784fcb960bdb7d080c86c4a2ea", null ],
    [ "m_minObjectSize", "class_base_detector.html#a651b938c89c94daac4763728637d90c9", null ],
    [ "m_motionMap", "class_base_detector.html#a45a2d54a0b69e271aa5c44ee301682b7", null ],
    [ "m_regions", "class_base_detector.html#a409c20093acba261db8354ca72058fce", null ]
];