var class_c_region =
[
    [ "CRegion", "class_c_region.html#a5f0eb7708629986b33543c3859ce782a", null ],
    [ "CRegion", "class_c_region.html#a5d052268a9412b514430f60c32765618", null ],
    [ "CRegion", "class_c_region.html#aa946953a5829934b7c235adf7e8a8517", null ],
    [ "m_confidence", "class_c_region.html#a349d846f135edc49a4c8f2db994b84b8", null ],
    [ "m_points", "class_c_region.html#a65be08ae81a8d174d95ae35a2f7fb212", null ],
    [ "m_rect", "class_c_region.html#a6f68304e90428db829cc38792fa3e1e8", null ],
    [ "m_type", "class_c_region.html#a287bf43ffa4837595762cbb007459a9a", null ]
];