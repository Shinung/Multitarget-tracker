var class_c_tracker =
[
    [ "CTracker", "class_c_tracker.html#a37a89d416c0a9f234b20849667a154c4", null ],
    [ "~CTracker", "class_c_tracker.html#ab74d4f1ce428c9d3fa9f9e9901a2070a", null ],
    [ "GrayFrameToTrack", "class_c_tracker.html#a9ddba40ad9a0196e1e75f9b9048be4f2", null ],
    [ "Update", "class_c_tracker.html#aad6f4e7a80a1b71522644a1f8c052f21", null ],
    [ "UpdateHungrian", "class_c_tracker.html#a9fd9223baba528c3c6522241391126ef", null ],
    [ "m_localTracker", "class_c_tracker.html#a0f7f687608e94fb1c1a94f49e7c2c784", null ],
    [ "m_nextTrackID", "class_c_tracker.html#acaa6995a64483d7666ff2117f1671fed", null ],
    [ "m_prevFrame", "class_c_tracker.html#a045ff08d0d83d89a9733657defdc9794", null ],
    [ "m_settings", "class_c_tracker.html#acb84aee0d550f4cdadbfac6735811050", null ],
    [ "tracks", "class_c_tracker.html#a86d322bc042985711c8d5ec8b9614230", null ]
];