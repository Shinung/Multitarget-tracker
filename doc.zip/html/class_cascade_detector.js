var class_cascade_detector =
[
    [ "CascadeDetector", "class_cascade_detector.html#a687a7c3ed39991cd3209d65283c0149b", null ],
    [ "~CascadeDetector", "class_cascade_detector.html#acd01c8d06da3ea93446d71f3d35f4e1e", null ],
    [ "AddNode", "class_cascade_detector.html#aa8759d8bdb90d648046aa72f0cf0fab3", null ],
    [ "length", "class_cascade_detector.html#a2ce4d234703b3332cf7e17624b3b30a5", null ],
    [ "nodes", "class_cascade_detector.html#a7977422f255cf4d753665c0c6a0b0f07", null ],
    [ "size", "class_cascade_detector.html#a4a1280062076bdea7b404e9fca3a53a4", null ]
];