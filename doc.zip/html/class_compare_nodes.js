var class_compare_nodes =
[
    [ "operator()", "class_compare_nodes.html#a8e0a0e6085d127c981736d579e398e09", null ]
];