var class_exec_context =
[
    [ "ExecContext", "class_exec_context.html#a88e6438e9e4bba24c27aa02ee5d40bd5", null ],
    [ "Activate", "class_exec_context.html#aad6945417b4a10d9ed0d338d16a1f105", null ],
    [ "CaffeClassifier", "class_exec_context.html#a6c596880b2a6a4c8df7e8ca639f2a1b7", null ],
    [ "Deactivate", "class_exec_context.html#a91a52dd30a857c8e71ea98976a9d44c2", null ],
    [ "IsCompatible", "class_exec_context.html#ae0873cef48079986d31639654f915bd0", null ],
    [ "allocator_", "class_exec_context.html#aa91ffaae541ca563b5aabb2f2a1c53b5", null ],
    [ "caffe_context_", "class_exec_context.html#a6561f67a969e8b38001d488e4937515f", null ],
    [ "detector_", "class_exec_context.html#acfecd6b6e282a7b7c67451dedd8bacae", null ],
    [ "device_", "class_exec_context.html#a05d01fbf5236f59519a9708580c175da", null ],
    [ "ScopedContext< ExecContext >", "class_exec_context.html#a5d1035fff84318aecd7d6b30c34c66f5", null ]
];