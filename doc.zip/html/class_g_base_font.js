var class_g_base_font =
[
    [ "GBaseFont", "class_g_base_font.html#ae2afea9a892bb4d271f5fadb4566336b", null ],
    [ "~GBaseFont", "class_g_base_font.html#a3517ce7aeadbbe9d77cab6e4a5aebe61", null ],
    [ "GetDescription", "class_g_base_font.html#a223b6eee3ba7e714d5dbb763ee4e3f9a", null ],
    [ "GetName", "class_g_base_font.html#a202a60eadc6436354527de8ccd4a983d", null ],
    [ "GetSize", "class_g_base_font.html#a62e761a8a0c0f60f01d8a0d451640e69", null ],
    [ "IsBold", "class_g_base_font.html#a22abd1f8dfcda6124ffedb8dc26bfcd3", null ],
    [ "IsItalic", "class_g_base_font.html#aec31b5754f2be8ae2552b2bfd37a76d1", null ],
    [ "bold", "class_g_base_font.html#a710baf8db958e41f964cb8af600df4c7", null ],
    [ "description", "class_g_base_font.html#a81dc0a7c8b42df0a39e49cc304da7d06", null ],
    [ "italic", "class_g_base_font.html#aeff487abd13b9a9110b18a89ad51975e", null ],
    [ "name", "class_g_base_font.html#a09217b162b03d74c2ea2e65bec537c5b", null ],
    [ "size", "class_g_base_font.html#a3665d1d315cccd1d1487eed589a8da0f", null ]
];