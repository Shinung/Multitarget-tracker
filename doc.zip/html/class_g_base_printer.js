var class_g_base_printer =
[
    [ "GBasePrinter", "class_g_base_printer.html#a070f83a6278ff1ac167a13802380b721", null ],
    [ "~GBasePrinter", "class_g_base_printer.html#a6d7e3c06b0131a5e3ed20b717c01ef82", null ],
    [ "AbortPrinting", "class_g_base_printer.html#a09ba32c950923f9b69a704a61652de6a", null ],
    [ "EndDoc", "class_g_base_printer.html#a98944a13eee52ae3fdbced5c7a317da6", null ],
    [ "EndPage", "class_g_base_printer.html#a3572e5164e69c0abcdb304a8b5f7ef5e", null ],
    [ "GetPhysicalPageRect", "class_g_base_printer.html#ab65d45881c40fbceca3c88b7b8f86800", null ],
    [ "GetPrintingRect", "class_g_base_printer.html#ad8008bef5f9aeed47354dcf4497ce450", null ],
    [ "PrinterSetup", "class_g_base_printer.html#a477d35154512e2c96971cf6bff8d3274", null ],
    [ "StartDoc", "class_g_base_printer.html#ac0052d2a156a45547cb23781500424c3", null ],
    [ "StartPage", "class_g_base_printer.html#a5c49511be188949312141af0b797ceba", null ]
];