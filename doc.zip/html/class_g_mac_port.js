var class_g_mac_port =
[
    [ "BeginGroup", "class_g_mac_port.html#a66b95b91c1a03a8200994ed2b7be4d67", null ],
    [ "DrawArc", "class_g_mac_port.html#af9375a9f4cd1bc94ac70eb71c437835a", null ],
    [ "DrawCircle", "class_g_mac_port.html#a7dbdd13c9a8f60537e7915a7991ab0f0", null ],
    [ "DrawLine", "class_g_mac_port.html#a9e19a5d97e629c3d19be31e1938504c1", null ],
    [ "DrawLinePts", "class_g_mac_port.html#ad176b1ff88c4c0a29d51869b13a288d2", null ],
    [ "DrawRect", "class_g_mac_port.html#a40b25399150458e4f41d4ed6b2f31f16", null ],
    [ "DrawText", "class_g_mac_port.html#a9b947d2575b05f303520fbbe7fd9e350", null ],
    [ "EndGroup", "class_g_mac_port.html#a0c29e4ce61f7c281f5cc9c04930db4fc", null ],
    [ "EndPicture", "class_g_mac_port.html#ac14e5cf72682662f8ac24c57e98b1bfa", null ],
    [ "GetCurrentDevice", "class_g_mac_port.html#aeca5105700149693465fb5dbc43c9bbc", null ],
    [ "GetDisplayRect", "class_g_mac_port.html#a2d6dd3aa5ad82b26ed614e139c2f6b8f", null ],
    [ "GetPenWidth", "class_g_mac_port.html#aeebcbb21b90ae5614d43b0111133932e", null ],
    [ "GetPrintingRect", "class_g_mac_port.html#af2e9e7d8adf001df68ab3e714dd4242e", null ],
    [ "SetCurrentFont", "class_g_mac_port.html#af297609a9f7ed9d29d77072037888f5e", null ],
    [ "SetDisplayRect", "class_g_mac_port.html#a8ac5424f05a6b6b982e570aae0802087", null ],
    [ "SetFillColorRGB", "class_g_mac_port.html#af13ac2220d4ff90a160294c79d4a2c1b", null ],
    [ "SetPenWidth", "class_g_mac_port.html#aa2fd1fbe050cfea5a21afb7d4cecaa61", null ],
    [ "StartPicture", "class_g_mac_port.html#aad9e21ed63c4f04a508e30b7f100fba5", null ],
    [ "Device", "class_g_mac_port.html#a14275a027c8665d5fa4941e148a1b46a", null ],
    [ "DisplayRect", "class_g_mac_port.html#ac0e1180ebadeed5d3c7d0291db1bdf29", null ],
    [ "PenWidth", "class_g_mac_port.html#a9a76c3a8af8d0e9f29035d02d8f038c1", null ]
];