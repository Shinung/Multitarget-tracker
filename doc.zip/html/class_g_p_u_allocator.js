var class_g_p_u_allocator =
[
    [ "GPUAllocator", "class_g_p_u_allocator.html#aa98cb14ed329cc0dfd99982da0d9b671", null ],
    [ "~GPUAllocator", "class_g_p_u_allocator.html#aacf971bf00e58690d44a52b9649d6e8d", null ],
    [ "allocate", "class_g_p_u_allocator.html#abe0cecfd551e4824ed5522721dea76ca", null ],
    [ "free", "class_g_p_u_allocator.html#a539a3d2909976f47ca7d109522c23ece", null ],
    [ "grow", "class_g_p_u_allocator.html#a04e2127f194094b27fe2351551c7ddeb", null ],
    [ "reset", "class_g_p_u_allocator.html#a4734a73038db3517f88a64e6b5f556ef", null ],
    [ "base_ptr_", "class_g_p_u_allocator.html#a3c2b70c86a428b4265771f9845307d0a", null ],
    [ "current_ptr_", "class_g_p_u_allocator.html#a34ef0b84f1e5a510c4c968889b2dbf04", null ],
    [ "current_size_", "class_g_p_u_allocator.html#a8d404f40928c431ced08c013189c8c58", null ],
    [ "total_size_", "class_g_p_u_allocator.html#a629bd3cca49d00f82cd6538e0d07d4ae", null ]
];