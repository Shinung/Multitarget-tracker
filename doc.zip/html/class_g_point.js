var class_g_point =
[
    [ "GPoint", "class_g_point.html#a8454b1fc2b2094d4cf5fd8d57a9114d9", null ],
    [ "GPoint", "class_g_point.html#a8198edcc7b38e155c8f1e117ca912fcb", null ],
    [ "GPoint", "class_g_point.html#a9344fd1bded86e274aad88fd85e0ee15", null ],
    [ "GetX", "class_g_point.html#a1abafe0e52e3f7039bbe0c0acbb5a9a9", null ],
    [ "GetY", "class_g_point.html#a0b40736448fc178ac2406875bd524a2c", null ],
    [ "Offset", "class_g_point.html#a8098fbfa3ada3a81e07313b2b4de1427", null ],
    [ "operator!=", "class_g_point.html#a7294abba5e2a5a7caa75e3967e07cbb5", null ],
    [ "operator==", "class_g_point.html#ae28ae2bca94c3b0906c3336c10545c94", null ],
    [ "SetPoint", "class_g_point.html#ad6f78b03b847082c2e2feb0a3612f0c5", null ],
    [ "SetX", "class_g_point.html#aa2e1b46333fea1d31b1db8eea7a4bbd6", null ],
    [ "SetY", "class_g_point.html#a20d2d7826baf36fe4b8f73b88d75cf7d", null ],
    [ "X", "class_g_point.html#a0a26572e08c37a5e7e6854ae8c7fee66", null ],
    [ "Y", "class_g_point.html#aca224bb9b30fab3b59cd25a9261c1069", null ]
];