var class_g_t_l__debug =
[
    [ "close_debug", "class_g_t_l__debug.html#a18b39d8b303a59062f86702a01ab6a98", null ],
    [ "debug_message", "class_g_t_l__debug.html#aca4c2fb24203b5fba5e4ffa9c2fa263f", null ],
    [ "init_debug", "class_g_t_l__debug.html#a119223c9000c1639d79d1a14a447c67a", null ],
    [ "os", "class_g_t_l__debug.html#a40282dee89c7cd8ea6bd02856e6cd73f", null ],
    [ "GTLerr", "class_g_t_l__debug.html#a342e76e2d4f128a29548aae14172db45", null ]
];