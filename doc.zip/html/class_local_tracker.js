var class_local_tracker =
[
    [ "LocalTracker", "class_local_tracker.html#a5b29d3a99a06b3efb3ef33b64965d217", null ],
    [ "~LocalTracker", "class_local_tracker.html#acf04cd253573c578a96292ba0af0dc94", null ],
    [ "Update", "class_local_tracker.html#a7fad09ebaf507de2a400ec17ec96fa56", null ]
];