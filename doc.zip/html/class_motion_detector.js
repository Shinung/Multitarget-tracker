var class_motion_detector =
[
    [ "MotionDetector", "class_motion_detector.html#a0df27eabc4f6d1cb55dc610dafa6a31f", null ],
    [ "~MotionDetector", "class_motion_detector.html#ad825ac5d27f840f3f6abcc0409aea71e", null ],
    [ "CalcMotionMap", "class_motion_detector.html#aa4e606acafdc33a3104471903e449adc", null ],
    [ "CollectPoints", "class_motion_detector.html#a20380b0980c6f262b0829f37fb89d2a7", null ],
    [ "Detect", "class_motion_detector.html#aac68875ab09d4436391855e2df4e0e06", null ],
    [ "DetectContour", "class_motion_detector.html#ab45a525c0ef2f5af9bc10c363c1b22e5", null ],
    [ "GetDetects", "class_motion_detector.html#a52ac4b2feed15a47de84a69eb45c233f", null ],
    [ "Init", "class_motion_detector.html#af59eda71fe52b578c08472425182dc41", null ],
    [ "SetMinObjectSize", "class_motion_detector.html#ab459f4e77cf1110cc1ee84027f0f2a03", null ],
    [ "m_algType", "class_motion_detector.html#a5254c16cea9d7a7155a35fd92c0b12ac", null ],
    [ "m_backgroundSubst", "class_motion_detector.html#ab0f8334cbe63bfaae0ed54650336e0d4", null ],
    [ "m_collectPoints", "class_motion_detector.html#a403cbf784fcb960bdb7d080c86c4a2ea", null ],
    [ "m_fg", "class_motion_detector.html#ac751815be986935ac095aff5428b6c24", null ],
    [ "m_minObjectSize", "class_motion_detector.html#a651b938c89c94daac4763728637d90c9", null ],
    [ "m_motionMap", "class_motion_detector.html#a45a2d54a0b69e271aa5c44ee301682b7", null ],
    [ "m_regions", "class_motion_detector.html#a409c20093acba261db8354ca72058fce", null ]
];