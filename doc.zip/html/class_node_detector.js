var class_node_detector =
[
    [ "NodeType", "class_node_detector.html#a7188c48dfe6b88b3b7f47c599c4832bd", [
      [ "CD_LIN", "class_node_detector.html#a7188c48dfe6b88b3b7f47c599c4832bda0fae40660f7fc68812bec11a7de3413e", null ],
      [ "CD_HIK", "class_node_detector.html#a7188c48dfe6b88b3b7f47c599c4832bda65deee8e79173b207da52debff561c83", null ],
      [ "LINEAR", "class_node_detector.html#a7188c48dfe6b88b3b7f47c599c4832bda92a38601f0cada88be925ffd8824effc", null ],
      [ "HISTOGRAM", "class_node_detector.html#a7188c48dfe6b88b3b7f47c599c4832bda4aa354e1c9fdf0c2fa2036b5922ccdf6", null ]
    ] ],
    [ "NodeDetector", "class_node_detector.html#af6107c5f4f78e4d60a720733e6fbcb5e", null ],
    [ "~NodeDetector", "class_node_detector.html#a3f8e6eedfce05ea8953ff1a41413ccfa", null ],
    [ "Classify", "class_node_detector.html#aa0fb033c9d770dda75236562784e9b88", null ],
    [ "Load", "class_node_detector.html#a8f28d4e33d23c0391511f795615b45d2", null ],
    [ "SetValues", "class_node_detector.html#a23a218ae9b613009bafcda85527a7dd7", null ],
    [ "classifier", "class_node_detector.html#a5eb3c12d3aa5250116334d6b4897ae47", null ],
    [ "featurelength", "class_node_detector.html#a3ebce10718457e7875c01dbe1eb77fa9", null ],
    [ "filename", "class_node_detector.html#ab4412f3aad986ffcc56289f95934ace1", null ],
    [ "index", "class_node_detector.html#a6a5fa5a89be5d2fd96b983f6afdab214", null ],
    [ "maxvalue", "class_node_detector.html#adb33cb202a422de76467e72f1b146610", null ],
    [ "minvalue", "class_node_detector.html#ab069f95bc20f00754a15c62c932b7e77", null ],
    [ "thresh", "class_node_detector.html#a2fd8792e80f3f31d2d07831a5169935f", null ],
    [ "type", "class_node_detector.html#a96a5ab514f7996e4e64fff8d37199f64", null ],
    [ "upper_bound", "class_node_detector.html#a904a3a37a99f506752794a979314548a", null ]
];