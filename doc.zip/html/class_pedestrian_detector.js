var class_pedestrian_detector =
[
    [ "DetectorTypes", "class_pedestrian_detector.html#aa2136624089c144b4ef5f3598de00d8c", [
      [ "HOG", "class_pedestrian_detector.html#aa2136624089c144b4ef5f3598de00d8ca47cb01f997c4439468112272761fc7de", null ],
      [ "C4", "class_pedestrian_detector.html#aa2136624089c144b4ef5f3598de00d8ca408a85378caa7239ba0ded11495782fd", null ]
    ] ],
    [ "PedestrianDetector", "class_pedestrian_detector.html#afdf81621958b3bd7083a67c76a535e4a", null ],
    [ "~PedestrianDetector", "class_pedestrian_detector.html#af093451952c64eb107ac2e2aff115b6c", null ],
    [ "CalcMotionMap", "class_pedestrian_detector.html#a73c66f0d4dad263fcf65c09a6f6feda2", null ],
    [ "CollectPoints", "class_pedestrian_detector.html#a20380b0980c6f262b0829f37fb89d2a7", null ],
    [ "Detect", "class_pedestrian_detector.html#a27a7c2c3b358f6e44a7de71f808597c2", null ],
    [ "GetDetects", "class_pedestrian_detector.html#a52ac4b2feed15a47de84a69eb45c233f", null ],
    [ "Init", "class_pedestrian_detector.html#a630d8ad4d8ca2123639e989b01c8dd3e", null ],
    [ "SetMinObjectSize", "class_pedestrian_detector.html#ab459f4e77cf1110cc1ee84027f0f2a03", null ],
    [ "HUMAN_height", "class_pedestrian_detector.html#a600b0da8ac472bcd8cb8aeb0e9f87eb7", null ],
    [ "HUMAN_width", "class_pedestrian_detector.html#afa7733c965e2d44d6908309b33201d90", null ],
    [ "HUMAN_xdiv", "class_pedestrian_detector.html#acdc72a22ba921457147c613ac874b3ed", null ],
    [ "HUMAN_ydiv", "class_pedestrian_detector.html#ab2626952044b310482883b506023e6a7", null ],
    [ "m_collectPoints", "class_pedestrian_detector.html#a403cbf784fcb960bdb7d080c86c4a2ea", null ],
    [ "m_detectorType", "class_pedestrian_detector.html#a4e0492d82780eb31f763972173d56d9d", null ],
    [ "m_hog", "class_pedestrian_detector.html#ad00796408688b6465fb988796536680d", null ],
    [ "m_minObjectSize", "class_pedestrian_detector.html#a651b938c89c94daac4763728637d90c9", null ],
    [ "m_motionMap", "class_pedestrian_detector.html#a45a2d54a0b69e271aa5c44ee301682b7", null ],
    [ "m_regions", "class_pedestrian_detector.html#a409c20093acba261db8354ca72058fce", null ],
    [ "m_scannerC4", "class_pedestrian_detector.html#a68a45a369623a3492065bdf29e81b29c", null ]
];