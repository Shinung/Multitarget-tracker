var class_s_s_d =
[
    [ "SSD", "class_s_s_d.html#ab89e65721f203d52f63b5e5d833d671c", null ],
    [ "Detect", "class_s_s_d.html#a35235278ff6d18ee494b2ccce3303c67", null ],
    [ "DetectAsMat", "class_s_s_d.html#a68c76ba1ebc94d222c1fd624db060f62", null ],
    [ "GetInputGeometry", "class_s_s_d.html#a20f17f5f9dbdc816f7b3ae4e30428427", null ],
    [ "GetLabel", "class_s_s_d.html#ac5c69f839f08bfa37dd33a66331f6fa3", null ],
    [ "GetLabels", "class_s_s_d.html#aca3c228118b686923b97cd120cf057c5", null ],
    [ "Predict", "class_s_s_d.html#a58c0ef81b4b24424fd967d90da5c6045", null ],
    [ "Preprocess", "class_s_s_d.html#a83cb8c64cda9b3792c5612613b56c828", null ],
    [ "SetMean", "class_s_s_d.html#ada3debdd0e04185587f13b44a6b63765", null ],
    [ "WrapInputLayer", "class_s_s_d.html#aec550d5312257216d93955cdee13a73e", null ],
    [ "allocator_", "class_s_s_d.html#af45a3ca33b8adcb4b2e23ebd23891947", null ],
    [ "conf_", "class_s_s_d.html#a2deab37585140ff74fbec6e54f5407bf", null ],
    [ "input_geometry_", "class_s_s_d.html#a3fe828551a5a53a3f43a481ae5d2d96a", null ],
    [ "labels_", "class_s_s_d.html#a1c4d34f2dda5d4ca2dfabbebff7a0ddb", null ],
    [ "mean_", "class_s_s_d.html#a3974a4a620cee93f5523c459482887e2", null ],
    [ "net_", "class_s_s_d.html#a9b70501b85252c3135030e5c6c1e7117", null ],
    [ "num_channels_", "class_s_s_d.html#affe6f7e948b0040bd958db34758d8ab1", null ]
];