var class_scoped_context =
[
    [ "ScopedContext", "class_scoped_context.html#a47e87cd0b7ce580d53fbb7f1bb36a4c3", null ],
    [ "~ScopedContext", "class_scoped_context.html#a1bdbdb322975a0ea7d35262385b81476", null ],
    [ "operator->", "class_scoped_context.html#af8a201a083905cf9c02c53d5992e7488", null ],
    [ "context_", "class_scoped_context.html#afe2f4971fc3620e98791cc844454956e", null ],
    [ "pool_", "class_scoped_context.html#a6aa628deb422cd0304c7b2eb311f8185", null ]
];