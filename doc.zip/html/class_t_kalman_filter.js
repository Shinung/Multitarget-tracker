var class_t_kalman_filter =
[
    [ "TKalmanFilter", "class_t_kalman_filter.html#a10f577570d5e6f6f6abdff0b816eb6c0", null ],
    [ "TKalmanFilter", "class_t_kalman_filter.html#aee7dc25f9fc4e72f627068ab0b56fd75", null ],
    [ "~TKalmanFilter", "class_t_kalman_filter.html#a19b5f44e8aadad2217ed3f2f370c8608", null ],
    [ "CreateLinear", "class_t_kalman_filter.html#a6b1bb8fb881f82ce0a766e6ea41f159c", null ],
    [ "CreateLinear", "class_t_kalman_filter.html#a1141fb38b6e9bfb1bef0d16686569978", null ],
    [ "GetPointPrediction", "class_t_kalman_filter.html#a103fb495ee14ff2be7a29053695ce7d1", null ],
    [ "GetRectPrediction", "class_t_kalman_filter.html#af112feed15a064055987a1faedf9673d", null ],
    [ "Update", "class_t_kalman_filter.html#a0c25b9a1a9676956aed0db44ad56696a", null ],
    [ "Update", "class_t_kalman_filter.html#a8018c71227761d4e7a2d83108eea0220", null ],
    [ "m_accelNoiseMag", "class_t_kalman_filter.html#a9f511e8885e5e89643fa6d59ea7bbd27", null ],
    [ "m_deltaTime", "class_t_kalman_filter.html#a7335e3bd7a695ebaf5eaa93c42e39eae", null ],
    [ "m_initialized", "class_t_kalman_filter.html#a5633e302e878261c8669816695f6a314", null ],
    [ "m_initialPoints", "class_t_kalman_filter.html#a5c4fc5a43ce0798dbe80f76f8aae2fc9", null ],
    [ "m_initialRects", "class_t_kalman_filter.html#a76f15da72d3613b8ba41a9eb38faaeac", null ],
    [ "m_lastPointResult", "class_t_kalman_filter.html#a91efb6a00cfae5df3e513ceba2239fa3", null ],
    [ "m_lastRect", "class_t_kalman_filter.html#a8e03a4e34d3f59c994a95ca0a5954a88", null ],
    [ "m_lastRectResult", "class_t_kalman_filter.html#aed4818c7aac455928ef02dd03f8bfe56", null ],
    [ "m_linearKalman", "class_t_kalman_filter.html#aec607aacb57ef1f78e514c6b3ef18435", null ],
    [ "m_type", "class_t_kalman_filter.html#a00cabc6683f6cc848559515df46d7101", null ],
    [ "MIN_INIT_VALS", "class_t_kalman_filter.html#a4511a3b64d2232e516b396e8783220cf", null ]
];