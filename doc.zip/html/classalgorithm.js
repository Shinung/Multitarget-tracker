var classalgorithm =
[
    [ "GTL_OK", "classalgorithm.html#af1a0078e153aa99c24f9bdf0d97f6710a5114c20e4a96a76b5de9f28bf15e282b", null ],
    [ "GTL_ERROR", "classalgorithm.html#af1a0078e153aa99c24f9bdf0d97f6710a6fcf574690bbd6cf710837a169510dd7", null ],
    [ "algorithm", "classalgorithm.html#ab79e1ddec2f2afdf4b36b10724db8b15", null ],
    [ "~algorithm", "classalgorithm.html#adca9b1e7fa3afd914519a9dbb44e9fd5", null ],
    [ "check", "classalgorithm.html#a76361fb03ad1cf643affc51821e43bed", null ],
    [ "reset", "classalgorithm.html#a21aba63d066ae7897de6ca7d8425c408", null ],
    [ "run", "classalgorithm.html#a734b189509a8d6b56b65f8ff772d43ca", null ]
];