var classedge__data =
[
    [ "adj_pos", "classedge__data.html#aa325caa449576727df8042bad875bf43", null ],
    [ "hidden", "classedge__data.html#af8dc68051e5fe3336aa31ae1f3e104c3", null ],
    [ "id", "classedge__data.html#a33597ce417f8d86697b03fc8b6fea526", null ],
    [ "nodes", "classedge__data.html#a870bbbb05de6c5f63d434db624c55dd4", null ],
    [ "owner", "classedge__data.html#a00436f2956a69cd9dc8e5bfa530e0ce9", null ],
    [ "pos", "classedge__data.html#a178a8fd40a6ec8139291f96a7807f711", null ]
];