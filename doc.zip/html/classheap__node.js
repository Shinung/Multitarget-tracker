var classheap__node =
[
    [ "heap_node", "classheap__node.html#a28a9434410001fe7fc975901ec6b7b33", null ],
    [ "heap_node", "classheap__node.html#a5f7209d13a6e95fe84770ea15c6a77b1", null ],
    [ "data", "classheap__node.html#ae37815e49df4d367e28ca4615b40e397", null ],
    [ "pos", "classheap__node.html#a6d6ebca320ede4a2dc3749caf0519534", null ]
];