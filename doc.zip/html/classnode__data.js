var classnode__data =
[
    [ "edges", "classnode__data.html#a91690d6d2594423c2cdf8ea083c8bd75", null ],
    [ "hidden", "classnode__data.html#a0a841a84f5038562908d726392ce1b55", null ],
    [ "id", "classnode__data.html#ac87541ac4470e3c17df808ec9a67f6c4", null ],
    [ "owner", "classnode__data.html#a20acb07c56fa28df6cbdbf3b0a02cb66", null ],
    [ "pos", "classnode__data.html#ab3deb00e39c12058e58a99a38507f344", null ]
];