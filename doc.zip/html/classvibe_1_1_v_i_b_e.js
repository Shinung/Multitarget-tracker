var classvibe_1_1_v_i_b_e =
[
    [ "VIBE", "classvibe_1_1_v_i_b_e.html#a57bebe0c56531dbd274e9d8e2a07fca5", null ],
    [ "~VIBE", "classvibe_1_1_v_i_b_e.html#ac74c9e86dff359028892e86ec699a17c", null ],
    [ "GetChannels", "classvibe_1_1_v_i_b_e.html#a8d325dc6deb7fc6e53e2c5074611c434", null ],
    [ "getMask", "classvibe_1_1_v_i_b_e.html#a8d8f40e61ee0bca8d7ab3fc4912a23dc", null ],
    [ "getRndNeighbor", "classvibe_1_1_v_i_b_e.html#a5ca071697edce3a8459f93cba2386516", null ],
    [ "init", "classvibe_1_1_v_i_b_e.html#a4db865cd319617161c13e4303471c33e", null ],
    [ "update", "classvibe_1_1_v_i_b_e.html#a9730e3695fa085ae907767390b3ad3de", null ],
    [ "channels_", "classvibe_1_1_v_i_b_e.html#a141be141bc39ddd6b9dd04df62b5e3b9", null ],
    [ "distance_threshold_", "classvibe_1_1_v_i_b_e.html#a2e55ef7f6496c14481359d9131135b2b", null ],
    [ "mask_", "classvibe_1_1_v_i_b_e.html#a7840cacb0f0c76e6280a8a4fad32e136", null ],
    [ "matching_threshold_", "classvibe_1_1_v_i_b_e.html#a70dd63f8644e1f36bfd32c58f02593ee", null ],
    [ "model_", "classvibe_1_1_v_i_b_e.html#af42cd53bbc91e95f14aa6c474bde5601", null ],
    [ "pixel_neighbor_", "classvibe_1_1_v_i_b_e.html#ace9a8955d2ca2acdcb8efe79a448ce7c", null ],
    [ "rng_", "classvibe_1_1_v_i_b_e.html#abc43782cfa12e3f055fa1212833f8595", null ],
    [ "rng_idx_", "classvibe_1_1_v_i_b_e.html#a76075aca9f68dffb84163e510b2dd122", null ],
    [ "samples_", "classvibe_1_1_v_i_b_e.html#ab27dfab66880b3b9fe8ceeafde283f4c", null ],
    [ "size_", "classvibe_1_1_v_i_b_e.html#a4748d53eff7e5a96ad4f98206dc7bb2c", null ],
    [ "update_factor_", "classvibe_1_1_v_i_b_e.html#a3abaee256b69fec3b0b49805a0e92e0c", null ]
];