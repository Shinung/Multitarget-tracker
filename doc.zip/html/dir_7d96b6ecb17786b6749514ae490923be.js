var dir_7d96b6ecb17786b6749514ae490923be =
[
    [ "c4-pedestrian-detector.cpp", "c4-pedestrian-detector_8cpp.html", "c4-pedestrian-detector_8cpp" ],
    [ "c4-pedestrian-detector.h", "c4-pedestrian-detector_8h.html", "c4-pedestrian-detector_8h" ]
];