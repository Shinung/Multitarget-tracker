var dir_af6d1ceb58c50107926e54522fcaba25 =
[
    [ "GTL", "dir_e6804bcc1277168e5594b912a36b8981.html", "dir_e6804bcc1277168e5594b912a36b8981" ],
    [ "components.cpp", "components_8cpp.html", "components_8cpp" ],
    [ "fheap.c", "fheap_8c.html", "fheap_8c" ],
    [ "fheap.h", "fheap_8h.html", "fheap_8h" ],
    [ "gdefs.h", "gdefs_8h.html", null ],
    [ "gml2dot.cpp", "gml2dot_8cpp.html", "gml2dot_8cpp" ],
    [ "gml2nestedsql.cpp", "gml2nestedsql_8cpp.html", "gml2nestedsql_8cpp" ],
    [ "gport.cpp", "gport_8cpp.html", "gport_8cpp" ],
    [ "gport.h", "gport_8h.html", "gport_8h" ],
    [ "mincut.cpp", "mincut_8cpp.html", null ],
    [ "mincut.h", "mincut_8h.html", "mincut_8h" ],
    [ "mwbmatching.cpp", "mwbmatching_8cpp.html", "mwbmatching_8cpp" ],
    [ "mwbmatching.h", "mwbmatching_8h.html", "mwbmatching_8h" ],
    [ "mygraph.cpp", "mygraph_8cpp.html", null ],
    [ "mygraph.h", "mygraph_8h.html", [
      [ "MyGraph", "class_my_graph.html", "class_my_graph" ]
    ] ],
    [ "mytree.cpp", "mytree_8cpp.html", "mytree_8cpp" ],
    [ "mytree.h", "mytree_8h.html", "mytree_8h" ],
    [ "rings.cpp", "rings_8cpp.html", "rings_8cpp" ],
    [ "script.cpp", "script_8cpp.html", "script_8cpp" ],
    [ "tokenise.cpp", "tokenise_8cpp.html", "tokenise_8cpp" ],
    [ "tokenise.h", "tokenise_8h.html", "tokenise_8h" ]
];