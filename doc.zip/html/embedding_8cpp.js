var embedding_8cpp =
[
    [ "operator<<", "embedding_8cpp.html#a5fbee94f64ccee2b6c19d095f09e0cbc", null ]
];