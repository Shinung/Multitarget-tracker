var files_dup =
[
    [ "Detector", "dir_f05c576c93f29c0a89698681fa56d8ab.html", "dir_f05c576c93f29c0a89698681fa56d8ab" ],
    [ "Tracker", "dir_88806f597a3ccbe0d489aab9688bf0d9.html", "dir_88806f597a3ccbe0d489aab9688bf0d9" ],
    [ "defines.h", "defines_8h.html", "defines_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "MouseExample.h", "_mouse_example_8h.html", "_mouse_example_8h" ],
    [ "nms.h", "nms_8h.html", "nms_8h" ],
    [ "run-code.py", "run-code_8py.html", "run-code_8py" ],
    [ "VideoExample.cpp", "_video_example_8cpp.html", "_video_example_8cpp" ],
    [ "VideoExample.h", "_video_example_8h.html", "_video_example_8h" ]
];